document.addEventListener("DOMContentLoaded",()=>{
    val = document.getElementById("val").value
    document.getElementById("jobs").innerHTML = val
})
